# SpriteMaker (RTX ON Level Editor)

SpriteMaker membuat atlas tekstur Rolling Sky (Enemy, TileGeneral, Mover / AutoMover, Fragile, Active) dari lapisan mask putih. Setiap lapisan diberi warna, opacity dan blend, lalu ditumpuk. Bawaannya **Massif/Default**.

Cara kerjanya sama dengan Texture Lab-mu (`Tools > Rolling Sky > Texture Lab`), tapi SpriteMaker ada **di dalam Level Editor** dan juga jalan di game hasil build (PC / APK). Hasilnya bisa langsung dipasang ke **Custom Theme** dengan tombol **Use**.

> Belum dites di Unity. Kalau ada error di Console, kirim screenshot-nya.

---

## Isi folder

```
Assets/
├── SpriteMaker/
│   ├── README.md                      ← file ini
│   └── Resources/SpriteMaker/
│       ├── index.txt                  ← daftar semua mask (dibaca SpriteMaker)
│       ├── MassifPresets.json         ← warna dan urutan Massif/Default (dari Texture Lab)
│       ├── LevelTexturePreview.json          ← level kecil untuk tombol 3D
│       ├── enemy/                     (+ topright/, topright/palettes/, bottomright/)
│       ├── general/
│       ├── fragile/
│       ├── fragileactive/
│       └── mover/
├── Scripts/SpriteMakerLab.cs           ← penyusun atlas (runtime)
├── Scripts/LevelEditor/SpriteMakerPanel.cs  ← jendela SPRITEMAKER
└── Editor/SpriteMakerImport.cs        ← menu RTX ON > SpriteMaker > Update Mask List
```

Mask-nya adalah 387 PNG dari `assets.zip`, tapi **berakhiran `.bytes`** (isinya tetap PNG). Alasannya:
- Ikut ke build dalam ukuran kecil (sekitar 2.5 MB). Kalau tetap `.png` di folder Resources, Unity menyimpannya sebagai tekstur tanpa kompresi, bisa ratusan MB.
- Pixelnya persis sama di semua platform, tanpa perlu mengatur Import Settings.

Folder `assets` asli untuk Texture Lab boleh tetap ada di tempatnya. Keduanya tidak saling ganggu.

## Cara buka

1. Level Editor, tombol **Theme**, lalu **+** (Custom Theme baru) atau **Edit** di theme Custom.
2. Tab **Textures**. Baris General, Fragile, FragileActive, Mover, MoverAuto, Enemy dan semua baris **Glow**-nya sekarang punya tombol **Make...**.
3. **Make...** membuka SPRITEMAKER di atlas yang cocok:

| Baris Custom Theme | Atlas SpriteMaker |
|---|---|
| General, General Glow | TileGeneral |
| Fragile, Fragile Glow | Fragile |
| FragileActive, FragileActive Glow | Active (FragileActive) |
| Mover, MoverAuto (+ Glow) | Mover / AutoMover |
| Enemy, Enemy Glow | Enemy |

4. Warnai, lalu **Use** (hijau, kanan atas). Atlasnya masuk ke baris tadi dan preview 3D Custom Theme langsung ikut berubah. Jangan lupa **Save** Custom Theme-nya.

Warna yang sudah kamu atur tetap tersimpan selama Level Editor terbuka. Jadi kalau General sudah diwarnai lalu kamu buka **General Glow**, warnanya masih sama. Supaya tidak hilang saat game ditutup, pakai **Project > Save...**.

## Jendela SPRITEMAKER

### Kiri: pengaturan

| Baris | Fungsi |
|---|---|
| **Atlas** `< >` | Ganti atlas: Enemy, TileGeneral, Mover / AutoMover, Fragile, Active, Enemy bottom right (25 frame animasi 256x128, hanya Save PNG). |
| **Show** | **Colour atlas** = tekstur biasa. **Glow map** = latar hitam dengan hanya lapisan yang **In glow map** (untuk baris Glow di Custom Theme: hitam = tidak menyala). |
| **Base colour** / **Base** | Warna solid di bawah semua lapisan. Off = tembus pandang. Atlas tile Massif memakainya. |
| **Project** | **Massif** = kembalikan atlas ini ke Massif/Default. **Open...** / **Save...** = file proyek `.json`. Formatnya sama dengan "Simpan proyek" Texture Lab, jadi bisa saling buka. |
| **Layer** | Lapisan yang dipilih (klik atlas atau klik baris di daftar). |
| **Visible** | Tampil / sembunyi. |
| **Colour** | Warna lapisan (color picker). |
| **Opacity** | 0 sampai 1 (geser lalu lepas). |
| **Blend** | **Normal**, **Glow (adds light)** = tambah terang (additive), **Multiply**, **Screen**. |
| **In glow map** | **Auto** = ikut kalau namanya ada "glow" atau blend-nya Glow. **Yes** / **No** = paksa. |
| **Order** | **Up** / **Down** memindah lapisan di daftar. Daftar digambar dari atas ke bawah, jadi lapisan yang lebih bawah menutupi yang di atasnya. |

Khusus **Enemy**:
- **Top right**: **Star** atau **Palette** (kubus, flip tile, rhombus, powerups). Masing-masing punya lapisan Massif sendiri.
- **Palette Order** (saat Palette): JSON yang sama dengan Texture Lab, contohnya `{"alwaysOnTop": true, "elements": [{"position": 1, "type": 0, "colors": ["#ff0000"]}]}`. **position** 1-12 = kotak di kanan atas (4 kolom x 3 baris), **type** 0-13 = bentuk palet, **colors** = warna tiap bagian. **Example** mengisi contoh 12 palet, **Import...** membaca file `.json`, **Clear** mengosongkan.
- **On top**: palet digambar di atas semua lapisan, atau tepat setelah `tr/basic_palette`.

Khusus **Enemy bottom right**: **Frame** `< >` memilih frame. Klik baris di daftar juga memilih frame.

### Tengah: atlas

- Latar kotak-kotak = bagian tembus pandang.
- **Klik atlas** untuk memilih lapisan teratas di titik itu. Kotak merah menandai lapisan yang dipilih, dan daftar di kanan ikut bergulir ke sana.

### Tombol 3D

**3D** (di atas, kiri dari Use) mengganti atlas di tengah dengan **LevelTexturePreview.json** dalam 3D. Level itu memakai Custom Theme yang sedang diedit, dengan atlas dari SpriteMaker ini. Setiap kali warna berubah, 3D-nya ikut berubah. Ini hanya pratinjau: Custom Theme baru berubah setelah **Use**.

- **Seret** gambar 3D ke atas/bawah, atau **scroll**, untuk maju/mundur sepanjang level.
- Tekan **3D** lagi untuk kembali ke atlas.
- Isi LevelTexturePreview.json: baris 0-1 Floor, baris 2-3 Jump dan Fragile, baris 5 Fragile checker, baris 6-8 Fragile dengan Roller ◄, baris 9-11 Floor dengan Riser serta Mover 1 (→) dengan Tree variant 3, baris 12 Floor dengan Pillar 3 dan Pillar 2, lalu Auto Mover 1 (←) dengan Mini offset ►.
- Ingin level lain? Buat level dengan **New+**, simpan dengan nama **LevelTexturePreview**. SpriteMaker memakai `LevelTexturePreview.json` di folder level dulu, kalau ada. Kalau tidak ada, yang dipakai adalah file bawaan di `Resources/SpriteMaker`.

### Pemilih warna

Tombol **Edit** pada warna mana pun membuka pemilih warna yang mirip Photoshop:

- **Kotak besar**: kiri-kanan = Saturation, bawah-atas = Brightness. **Batang di sebelahnya** = Hue. Klik atau seret keduanya.
- **new** (atas) dan **current** (bawah). Klik **current** untuk kembali ke warna awal.
- **H / S / B** dan **R / G / B** bisa diketik. **#** = Hex, misalnya `FFCC00` (boleh ditempel dengan `#`, atau 3 digit seperti `FC0`).
- **Eyedropper**: jendela pemilih hilang sebentar, lalu klik warna apa saja di layar (atlas, 3D, gambar lain di editor). Kotak kecil di samping kursor menunjukkan warna dan Hex-nya. **Klik kanan** atau **Esc** = batal. Di HP: tahan, geser, lalu lepas.
- **Realtime**: warna langsung dipakai saat digeser atau diketik, jadi atlas dan 3D ikut berubah. **OK** = simpan, **Cancel** / **Esc** = kembali ke warna awal.
- **Geser jendela**: seret strip paling atas (tulisan "drag to move") supaya bagian di belakangnya terlihat.
- **Recent**: 12 warna terakhir yang di-OK (tetap ada walau editor ditutup). Klik untuk memakai lagi.

### Gambar referensi

Tombol **Reference** (di atas) membuka jendela kecil berisi gambar PNG / JPG bebas dari komputer, misalnya screenshot Rolling Sky asli, untuk dicontoh warnanya.

- Pertama kali, Reference langsung minta file. Gambar terakhir diingat dan terbuka lagi saat Reference ditekan berikutnya.
- **Open...** = ganti gambar. **-** / **+** = perkecil / perbesar. **X** atau **Reference** lagi = sembunyikan.
- **Geser jendela**: seret strip paling atas.
- **Klik gambar** = ambil warna piksel itu persis (tanpa blur). Kalau pemilih warna sedang terbuka, warnanya masuk ke situ (lalu OK). Kalau tidak, warnanya langsung dipakai lapisan yang sedang dipilih.
- **Eyedropper** di pemilih warna juga bisa mengambil warna dari gambar referensi.

### Kanan: daftar lapisan

- Kotak kecil = warna lapisan. Tombol **on / off** = tampil / sembunyi.
- **Search layers...** menyaring daftar (misalnya `border`, `palette`, `glow`, `mv/`).
- **All on** / **All off** berlaku untuk lapisan yang tersaring.
- **Colour...** mewarnai semua lapisan yang tersaring sekaligus (harus ada kata pencarian).
- **Glow** memasukkan semua lapisan yang tersaring ke glow map, atau mengeluarkannya kalau semuanya sudah masuk.

### Atas

- **Use**: pasang ke baris Custom Theme yang membuka SpriteMaker. Kalau Show = Glow map, yang dipasang adalah glow map-nya.
- **Reference**: buka gambar referensi (lihat di atas).
- **Save PNG**: simpan yang terlihat (atlas atau glow map) ke file PNG.
- **X** / **Esc**: tutup.

## Membuat Glow

Tile Massif tidak punya lapisan bernama "glow", jadi glow map tile awalnya hitam semua. Caranya:
1. **Make...** di baris **General Glow** (SpriteMaker langsung membuka Show = Glow map).
2. Cari `border`, lalu tekan **Glow**. Semua garis tepi masuk ke glow map.
3. Warnanya boleh putih saja. Warna dan kekuatan glow di game diatur di Custom Theme > **ColorSets** > Tile Glow colour / strength.
4. **Use**.

Enemy punya lapisan `..._glow` yang otomatis masuk glow map, jadi **Enemy Glow** langsung terisi.

**Palette di Enemy Glow** (Top right = Palette): di glow map, setiap kotak palette hanya menyala di **tengahnya**. Kotak 16 px jadi 6 px, sisanya transparan. Tempat 64 x 64 milik setiap palette juga dibuat transparan dulu, jadi `tr/basic_palette` tidak ikut terlihat di sana. Atur di baris **Glow palettes**:
- **Size** berganti antara: `6 of 16 px` (bawaan, sebanding: 16 → 6, 32 → 12, 64 → 24), `6 px` (paling besar 6 px), `Full` (seluruh kotak), `None` (tanpa palette).
- **Same** = warnanya sama dengan Palette Order (bawaan).
- **Import...** = Palette Order JSON khusus untuk glow map (formatnya sama, misalnya dari tombol Example). Atlas warna tetap memakai Palette Order biasa.
- Kotak yang tertutup kotak lain (misalnya 2-4 sampai 2-6 di bawah 3-1-1 pada type 5/6) tetap tersembunyi.

## Di game hasil build (PC / APK)

- SpriteMaker jalan juga karena mask-nya ada di Resources.
- **Save PNG**, **Save...** menulis ke folder `Export` di save folder game. **Open...** dan **Import...** membaca dari folder `Import` (Android: `Android/data/<nama game>/files/Import`).

## Menambah atau mengganti mask

1. Taruh PNG-nya (putih + alpha, 512x512, atau 64x64 untuk palet) di folder yang sesuai di `Assets/SpriteMaker/Resources/SpriteMaker/`.
2. Menu **RTX ON > SpriteMaker > Update Mask List**. Menu ini mengganti `.png` jadi `.bytes` dan menulis ulang `index.txt`.
3. Lapisan baru muncul dalam keadaan **off** di atlas yang memakai folder itu. Nyalakan dan beri warna.

## Kalau ada masalah

- **"No masks found"**: folder `Assets/SpriteMaker/Resources/SpriteMaker/` atau `index.txt` belum ada. Salin ulang folder SpriteMaker dari RTXOn.zip.
- **Atlas kosong / ada lapisan yang hilang**: jalankan **RTX ON > SpriteMaker > Update Mask List**.
- **Warna beda dengan Texture Lab**: lapisan dan rumus blend-nya sama, jadi hasil seharusnya sama. Kirim screenshot keduanya.

## Kredit

Mask dari `assets.zip` ("Default Assets" oleh sqdldev, Rolling Sky SpriteMaker). Urutan dan warna Massif/Default dari `MassifPresets.json` Texture Lab milik Adrian.
