package com.rtxon.files;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;

import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Android's own file window (Storage Access Framework) for the RTX ON level editor (NativeFiles.cs).
 * pick: the player chooses any file (Download, Drive, WhatsApp...); it is copied into the app's cache and its path
 * goes back to Unity. save: the player chooses where a file the game wrote goes, and it is copied there.
 * The answer reaches Unity with UnitySendMessage: a path / file name, "" when cancelled, "!message" on a problem.
 */
public class RTXOnFiles extends Fragment {
    private static final int PICK = 0x5254, SAVE = 0x5255;
    private static final String TAG = "RTXOnFiles";

    private String receiver, mode, source, name, mime;
    private boolean asked;

    public static void pick(Activity activity, String receiver) {
        start(activity, receiver, "pick", null, null, null);
    }

    public static void save(Activity activity, String receiver, String source, String name, String mime) {
        start(activity, receiver, "save", source, name, mime);
    }

    private static void start(final Activity activity, final String receiver, final String mode,
                              final String source, final String name, final String mime) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    RTXOnFiles f = new RTXOnFiles();
                    f.receiver = receiver;
                    f.mode = mode;
                    f.source = source;
                    f.name = name;
                    f.mime = mime;
                    activity.getFragmentManager().beginTransaction().add(f, TAG).commitAllowingStateLoss();
                } catch (Exception e) {
                    send(receiver, mode, "!" + e.getMessage());
                }
            }
        });
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setRetainInstance(true); // keeps the request when the screen turns while the file window is open
        if (asked || receiver == null) return;
        asked = true;
        Intent intent;
        boolean saving = "save".equals(mode);
        if (saving) {
            intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime != null ? mime : "application/octet-stream");
            intent.putExtra(Intent.EXTRA_TITLE, name);
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*"); // .rsrt, .themert... have no type Android knows
        }
        try {
            startActivityForResult(intent, saving ? SAVE : PICK);
        } catch (Exception e) {
            finish("!" + e.getMessage());
        }
    }

    @Override
    public void onActivityResult(int request, int result, Intent data) {
        String answer = "";
        if (result == Activity.RESULT_OK && data != null && data.getData() != null) {
            try {
                answer = request == SAVE ? write(data.getData()) : read(data.getData());
            } catch (Exception e) {
                answer = "!" + e.getMessage();
            }
        }
        finish(answer);
    }

    private String read(Uri uri) throws IOException {
        File folder = new File(getActivity().getCacheDir(), "Picked");
        if (!folder.exists() && !folder.mkdirs()) throw new IOException("can't make " + folder);
        File out = new File(folder, displayName(uri));
        copy(getActivity().getContentResolver().openInputStream(uri), new FileOutputStream(out));
        return out.getAbsolutePath();
    }

    private String write(Uri uri) throws IOException {
        copy(new FileInputStream(source), getActivity().getContentResolver().openOutputStream(uri, "w"));
        return displayName(uri);
    }

    private String displayName(Uri uri) {
        String found = null;
        Cursor c = null;
        try {
            c = getActivity().getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) found = c.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        if (found == null || found.isEmpty()) found = uri.getLastPathSegment();
        if (found == null || found.isEmpty()) found = "file";
        return found.replace('/', '_').replace('\\', '_').replace(':', '_');
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        if (in == null || out == null) throw new IOException("the file could not be opened");
        try {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            out.flush();
        } finally {
            try { in.close(); } catch (IOException ignored) { }
            try { out.close(); } catch (IOException ignored) { }
        }
    }

    private void finish(String answer) {
        send(receiver, mode, answer);
        try {
            getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
        } catch (Exception ignored) {
        }
    }

    private static void send(String receiver, String mode, String answer) {
        UnityPlayer.UnitySendMessage(receiver, "save".equals(mode) ? "OnSaved" : "OnPicked", answer == null ? "" : answer);
    }
}
